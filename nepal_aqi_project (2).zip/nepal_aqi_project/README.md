# Nepal Air Quality — AQI Classification & Dashboard

An AI/ML project that classifies Nepal air quality into AQI categories from PM2.5, PM10,
and NO2 readings, with a district-wise dashboard (historical data) and a live AI prediction
panel (two independently trained models: an MLP neural network and a from-scratch DNN).

## Project structure

```
nepal_aqi_project/
├── README.md                 <- this file
├── requirements.txt
├── notebook/
│   └── Nepal_AQI_NN_and_DNN_Classification_IMPROVED.ipynb   <- full analysis, executed
├── models/                   <- trained model artifacts (already generated, ready to use)
│   ├── scaler.joblib
│   ├── label_encoder.joblib
│   ├── mlp_model.pt          <- PyTorch state_dict
│   ├── dnn_model.pt          <- PyTorch state_dict
│   ├── meta.json
│   └── district_stats.json
├── backend/
│   └── main.py                <- FastAPI app: serves the API + the static frontend
└── frontend/
    ├── index.html
    ├── style.css
    └── script.js
```

## Before you run anything: read this

The dataset's original `AQI` column has **no real relationship** to PM2.5, PM10, NO2,
district, station, or time — verified with mutual information, an all-features Random
Forest, and a flat/uniform histogram (all in the notebook, Section 7.1). No model, however
tuned, can learn to predict it. Instead, this project uses a **`Calculated_AQI`** target,
computed directly from PM2.5/PM10/NO2 using the EPA's actual published AQI formula (Section
7.2 of the notebook) — a legitimate, defensible target with real signal (r≈0.88 with PM2.5).
Both models here are trained and evaluated on `Calculated_AQI_Category`, not the original
`AQI` column. The dashboard is explicit about this distinction throughout.

### Class imbalance & accuracy — what was actually done

- `Calculated_AQI_Category` is imbalanced (Hazardous ≈46.5%, Moderate ≈2.1%, "Good" never
  occurs in this dataset — pollutant readings never get low enough). Both models (a PyTorch
  MLP and a deeper PyTorch DNN) are trained with `nn.CrossEntropyLoss(weight=...)` using
  `sklearn.utils.class_weight.compute_class_weight('balanced', ...)` — the imbalance is
  handled directly in the loss function, no oversampling or synthetic rows needed.
- Both models are already close to the practical ceiling for this target —
  `Calculated_AQI` is a near-deterministic function of the 3 input features, so there isn't
  much room to "improve" further without risking overfitting to noise.
- Current exported models (held-out test set, in `models/meta.json`):
  **MLP — accuracy 0.996, macro F1 0.993. DNN — accuracy 0.988, macro F1 0.986.**

## 1. Set up

```bash
cd nepal_aqi_project
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 2. (Optional) Regenerate the models from scratch

The `models/` folder already has everything the dashboard needs — you can skip straight to
step 3. Only do this if you want to re-run the analysis yourself (e.g. with updated data):

1. Open `notebook/Nepal_AQI_NN_and_DNN_Classification_IMPROVED.ipynb` in Jupyter or Colab.
2. Make sure the Nepal Air Quality Excel file is either in the same folder as the notebook,
   or update `DATA_FILENAME` near the top of the data-loading cell to point at it.
3. Run all cells. Section 8's last cell saves the split model files straight into a
   `models/` folder next to wherever the notebook runs — copy that folder over
   `nepal_aqi_project/models/` (overwriting the old one) when it's done.

## 3. Run the backend (serves both the API and the dashboard)

```bash
cd backend
uvicorn main:app --reload
```

Leave this running, then open **http://127.0.0.1:8000** in your browser. That's it — the
same FastAPI server serves the dashboard pages *and* answers the prediction requests, so
there's nothing else to start.

## 4. Using the dashboard

- **Historical / Dataset AQI** (top card) — pick a district from the dropdown. Everything
  shown (AQI status, PM2.5, PM10, NO2) is a real average pulled from the dataset via
  `GET /api/districts`, not hard-coded.
  - Note: "Kathmandu" is not a named district in this dataset — a 10th monitoring station
    has no location metadata in the source file, so it's excluded rather than guessed at.
  - Note: per-district pollutant averages are nearly identical across all 9 districts in
    this dataset — real numbers, just not very differentiated at the district level.
- **AI Prediction** (bottom card) — enter PM2.5 / PM10 / NO2 and click Predict. This calls
  `POST /api/predict`, which runs both trained models server-side and returns each one's
  predicted category plus a full probability breakdown across **all 6** official AQI
  categories (any category with no training examples, e.g. "Good", is shown at 0% with a
  "no training data" tag rather than silently omitted).

## API reference

| Method | Path             | Returns                                                        |
|--------|------------------|-----------------------------------------------------------------|
| GET    | `/`              | the dashboard (`frontend/index.html`)                          |
| GET    | `/api/meta`      | feature order, AQI category list, which models are loaded, their macro F1 |
| GET    | `/api/districts` | per-district averages (PM2.5, PM10, NO2, Calculated_AQI, status) |
| POST   | `/api/predict`   | `{"PM2_5_ug_m3": .., "PM10_ug_m3": .., "NO2_ppb": ..}` → both models' predictions |

## Troubleshooting

- **"Address already in use"** — another process is on port 8000; run
  `uvicorn main:app --reload --port 8001` and open that port instead.
- **Dashboard loads but shows no data / network errors** — the backend isn't running, or
  you opened `frontend/index.html` directly as a file instead of going through
  `http://127.0.0.1:8000`. The frontend calls relative API paths (`/api/...`), so it must be
  served by FastAPI, not opened standalone.
- **`FileNotFoundError` for a `.joblib` / `.npz` file on backend startup** — you're running
  `uvicorn` from somewhere other than the `backend/` folder, or `models/` is missing a file;
  re-check the folder structure above.
